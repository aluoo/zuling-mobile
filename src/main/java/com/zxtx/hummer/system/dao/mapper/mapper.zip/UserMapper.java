package com.smotech.nvwa.system.dao.mapper;

import com.smotech.nvwa.system.domain.UserDO;
import com.smotech.nvwa.system.shiro.LoginUser;
import com.smotech.nvwa.system.vo.UserFullInfVo;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author chglee
 * @email 1992lcg@163.com
 * @date 2017-10-03 09:45:11
 */

public interface UserMapper {

	UserDO get(Long userId);

	long getUserIdByEmployeeId(Long employeeId);
	
	List<UserDO> list(Map<String,Object> map);

	List<UserFullInfVo> lsUserFullInfo(Map<String,Object> map);
	
	int count(Map<String,Object> map);
	
	int save(UserDO user);
	
	int update(UserDO user);
	
	int remove(Long userId);
	
	int batchRemove(Long[] userIds);
	
	Long[] listAllDept();

	LoginUser getLoginUser(Long userId);

	int removeByEmployeeId(Long employeeId);

}
